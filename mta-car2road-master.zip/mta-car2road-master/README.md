# Car2road
When your car fall in love with water teleports your car into nearest route.
    
### Installation
Move in to ```${SERVER_DIR}\mods\deathmatch\resources``` folder.
Type ```refresh``` command on console.
Finally you can do ```start mta-car2road```

------

## Türkçe Dökümantarnasyon
Suya düşen araçlar otomatik olarak en yakın yola ışınlanır, oyuncular yüzebilir, uçaklar ve gemileri etkilemez.
    
### Kurulum
İndirilen dosyayı ```${SUNUCU_KLASORU}\mods\deathmatch\resources``` klasörüne kopyalayın.

Konsol'a ```refresh``` komutunu girin.

Son olarak sistem yüklendikten sonra ```start mta-car2road``` komutu ile başlatabilirsiniz.

------
![Image of before](https://community.multitheftauto.com/images/gallery/car2road/31070.png)
![Image of after](https://community.multitheftauto.com/images/gallery/car2road/31071.png)
