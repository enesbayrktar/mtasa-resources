# Shade
A complex shade pack resource for Multi Theft Auto.
    
### Installation
Move in to ```${SERVER_DIR}\mods\deathmatch\resources``` folder.
Type ```refresh``` command on console.
Finally you can do ```start mta-shade```

------

## Türkçe Dökümantarnasyon
Multi Theft Auto için yapılmış kompleks bir grafik paketi sistemidir, sunucunuza yükledikten sonra değişikliklere bakabilirsiniz.
    
### Kurulum
İndirilen dosyayı ```${SUNUCU_KLASORU}\mods\deathmatch\resources``` klasörüne kopyalayın.

Konsol'a ```refresh``` komutunu girin.

Son olarak sistem yüklendikten sonra ```start mta-shade``` komutu ile başlatabilirsiniz.

------
*forks:* ```https://community.multitheftauto.com/?p=resources&s=details&id=18094```

*kaynakça:* ```https://community.multitheftauto.com/?p=resources&s=details&id=18094```
