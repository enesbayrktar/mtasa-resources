# Ped Aim FPS
When your car fall in love with water teleports your car into nearest route.
    
### Installation
Move in to ```${SERVER_DIR}\mods\deathmatch\resources``` folder.
Type ```refresh``` command on console.
Finally you can do ```start mta-pedaimfps```

------

## Türkçe Dökümantarnasyon
Oyuncuların nişan alırkenki fps değerlerini eşitler.
    
### Kurulum
İndirilen dosyayı ```${SUNUCU_KLASORU}\mods\deathmatch\resources``` klasörüne kopyalayın.

Konsol'a ```refresh``` komutunu girin.

Son olarak sistem yüklendikten sonra ```start mta-pedaimfps``` komutu ile başlatabilirsiniz.
